import prac2.trafico.*;

/**
 * Clase de ejemplo entregada por los profesores.
 */
public class Ejemplo1 {

	/**
	 * Clase main
	 * @param args argumentos de entrada.
	 */
	public static void main(String[] args) {
		Coche fiat500x = new Coche("Fiat 500x", 2019, true);
		Coche minic = new Coche("Mini Copper", 2015, false);
		Coche xsara = new Coche("Citroen XSara", 1997, true);
		
		Vehiculo [] vehiculos = { fiat500x, minic, xsara };
		
		for (Vehiculo v : vehiculos )  
			System.out.println(v);
		
	}

}
