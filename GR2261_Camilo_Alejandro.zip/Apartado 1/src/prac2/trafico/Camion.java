package prac2.trafico;

/**
 * Clase heredera de vehiculo para la creacion de objetos de tipo Camion.
 *
 * @author Alejandro Hurtado alejandror.hurtado@estudiante.uam.es
 * @author Camilo Jene camilo.jenec@estudiante.uam.es
 */
public class Camion extends Vehiculo{
    /**
     * Numero de ejes que tiene el Camion.
     */
    private int numEjes = 0;

    /**
     * Constructor de la clase Camion.
     *
     * @param mod modelo
     * @param a a�o
     * @param matricula matricula
     * @param numEjes numero de ejes
     */
    public Camion(String mod, int a, String matricula, int numEjes) {
        super(mod, a, matricula);
        this.numEjes = numEjes;
    }

    /**
     * Metodo que devuelve el numero de ejes del Camion.
     *
     * @return numEjes
     */
    public int getNumEjes() {
        return numEjes;
    }

    /**
     * Metodo para alterar el valor del atributo numEjes.
     *
     * @param numEjes numero Ejes
     */
    public void setNumEjes(int numEjes) {
        this.numEjes = numEjes;
    }

    /**
     * Metodo que devuelve el numero de ruedas de un Camion.
     *
     * @return int
     */
    @Override
    public int numeroRuedas() {
        return 2 * numEjes;
    }

    /**
     * Metodo que devuelve el Indice de Contaminacion del Camion.
     *
     * @return IndiceContaminacion
     */
    @Override
    public IndiceContaminacion getIndiceContaminacion() {
        if (numEjes > 2) return IndiceContaminacion.C;
        else return super.getIndiceContaminacion();
    }

    /**
     * toString que imprime la informacion del Camion.
     *
     * @return String
     */
    @Override
    public String toString() {
        return "Cami�n de " + numEjes + " ejes, " + super.toString();

    }
}