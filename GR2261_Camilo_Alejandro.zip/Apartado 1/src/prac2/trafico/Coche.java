package prac2.trafico;

/**
 * Clase heredera de vehiculo para la creacion de objetos de tipo coche.
 *
 * @author Alejandro Hurtado alejandror.hurtado@estudiante.uam.es
 * @author Camilo Jene camilo.jenec@estudiante.uam.es
 */
public class Coche extends Vehiculo {

	/**
	 * Booleano que indica si el Coche tiene motor diesel o no.
	 */
	private boolean diesel;

	/**
	 * Constructor de la clase Coche sin matricula para el Ejercicio1.
	 *
	 * @param mod modelo
	 * @param a a�o
	 * @param diesel diesel
	 */
	public Coche(String mod, int a, boolean diesel) {
		super(mod, a);
		this.diesel = diesel;
	}

	/**
	 * Constructor de la clase Coche con matricula para el Ejercicio2.
	 *
	 * @param mod modelo
	 * @param a a�o
	 * @param matricula matricula
	 * @param diesel diesel
	 */
	public Coche(String mod, int a, String matricula, boolean diesel) {
		super(mod, a, matricula);
		this.diesel = diesel;
	}

	/**
	 * M�todo que devuelve el numero de ruedas que tiene un coche.
	 *
	 * @return 4
	 */
	@Override public int numeroRuedas() { return 4;	}

	/**
	 * toString que devuelve la informacion del Coche.
	 *
	 * @return String
	 */
	@Override public String toString() {
		return "Coche "+(this.diesel ? "diesel" : "gasolina") + ", "+ super.toString();
	}

	/**
	 * Metodo que devuelve el Indice de contaminacion del Coche llamando a la funcion del padre.
	 *
	 * @return IndiceContaminacion
	 */
	@Override
	public IndiceContaminacion getIndiceContaminacion() {
		if (this.diesel) return IndiceContaminacion.C;
		return super.getIndiceContaminacion();
	}

	/**
	 * Metodo que devuelve un booleano que indica si el coche tiene motor diesel o no.
	 *
	 * @return Boolean
	 */
	public boolean getDiesel() { return this.diesel; }

	/**
	 * Metodo que permite alterar el valor del atributo diesel del Coche.
	 *
	 * @param b Boolean
	 */
	public void setDiesel(boolean b) { this.diesel = b; }
}
