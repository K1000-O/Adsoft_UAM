package prac2.trafico;

/**
 * Clase con los datos necesarios para las Motocicletas.
 *
 * @author Alejandro Raul Hurtado alejandror.hurtado@estudiante.uam.es
 * @author Camilo Jene Conde camilo.jenec@estudiante.uam.es
 */
public class Motocicleta extends Vehiculo{
    /**
     * Variable para saber si la moto es electrica.
     */
    private final Boolean esElectrica;

    /**
     * Constructor de Motocicleta.
     * @param mod modelo de la moto.
     * @param a a�o de compra de la moto.
     * @param matricula matr�cula de la moto.
     * @param esElectrica si es electrica o no.
     */
    public Motocicleta(String mod, int a, String matricula, Boolean esElectrica) {
        super(mod, a, matricula);
        this.esElectrica = esElectrica;
    }

    /**
     * Numero de ruedas de la moto.
     * @return int
     */
    @Override
    public int numeroRuedas() {
        return 2;
    }

    /**
     * Devolver si la moto es electrica o no.
     * @return True si es electrica, False si no lo es.
     */
    public Boolean getEsElectrica() {
        return esElectrica;
    }

    /**
     * M�todo que devuelve el �ndice de contaminaci�n.
     * @return A si es electrica else si no lo es.
     */
    @Override
    public IndiceContaminacion getIndiceContaminacion() {
        if (esElectrica) return IndiceContaminacion.A;
        else return super.getIndiceContaminacion();
    }

    /**
     * toString que imprime algo determinado.
     * @return String
     */
    @Override
    public String toString() {
        return "Motocicleta" + (getEsElectrica() ? " electrica, " : ", ") + super.toString();
    }
}
