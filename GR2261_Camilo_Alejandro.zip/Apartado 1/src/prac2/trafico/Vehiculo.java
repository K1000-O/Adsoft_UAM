package prac2.trafico;

/**
 * Clase abstracta para la creacion de diferentes vehiculos que heredan de �sta.
 *
 * @author Alejandro Raul Hurtado alejandror.hurtado@estudiante.uam.es
 * @author Camilo Jene Conde camilo.jenec@estudiante.uam.es
 */
public abstract class Vehiculo {
	/**
	 * Nombre del modelo del vehiculo
	 */
	private String modelo;
	/**
	 * Matricula del vehiculo
	 */
	private String matricula;
	/**
	 * A�o de compra del vehiculo
	 */
	private int anyoCompra;

	/**
	 * Constructor del vehiculo sin matricula.
	 * @param mod modelo
	 * @param a a�o
	 */
	public Vehiculo(String mod, int a) {
		this.modelo = mod;
		this.anyoCompra = a;
	}

	/**
	 * Constructor del vehiculo con matricula.
	 * @param mod modelo
	 * @param a a�o
	 * @param matricula matricula
	 */
	public Vehiculo(String mod, int a, String matricula) {
		this(mod, a);
		this.matricula = matricula;
	}

	/**
	 * toString sobreescrito para imprimir algo definido.
	 * @return String
	 */
	@Override
	public String toString() {
		return "modelo "+this.modelo+(matricula != null ? ", matr�cula: " + this.matricula : "")+", fecha compra "+this.anyoCompra+", con "+
				this.numeroRuedas()+" ruedas, �ndice:"+this.getIndiceContaminacion();
	}

	/**
	 * Metodo abstracto numero de ruedas del vehiculo
	 * @return int numero de ruedas
	 */
	public abstract int numeroRuedas();

	/**
	 * M�todo que devuelve el indice de contaminacion dependiendo del a�o de compra.
	 * @return IndiceContaminacion
	 */
	public IndiceContaminacion getIndiceContaminacion() {
		return IndiceContaminacion.getIndiceContaminacion(this.anyoCompra);
	}
}
